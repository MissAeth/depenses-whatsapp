var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/whatsapp/route.js")
R.c("server/chunks/node_modules_next_7c4fb177._.js")
R.c("server/chunks/[root-of-the-server]__2bd87657._.js")
R.c("server/chunks/_next-internal_server_app_api_whatsapp_route_actions_d84fa5aa.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/whatsapp/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/whatsapp/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
