module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[project]/src/lib/ai-processor.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Module IA pour l'extraction automatique des données de dépenses
 * Utilise Tesseract OCR + patterns regex + IA locale (optionnel)
 */ // Types pour les données extraites
__turbopack_context__.s([
    "processExpenseContent",
    ()=>processExpenseContent,
    "testAIProcessor",
    ()=>testAIProcessor
]);
// Catégories et mots-clés pour la classification
const CATEGORY_KEYWORDS = {
    'Transport': [
        'taxi',
        'uber',
        'sncf',
        'metro',
        'bus',
        'essence',
        'carburant',
        'parking',
        'péage',
        'autoroute',
        'vtc',
        'blablacar'
    ],
    'Restauration': [
        'restaurant',
        'café',
        'bar',
        'boulangerie',
        'mcdo',
        'pizza',
        'food',
        'resto',
        'déjeuner',
        'diner',
        'bistrot'
    ],
    'Hébergement': [
        'hotel',
        'airbnb',
        'booking',
        'hébergement',
        'nuit',
        'chambre',
        'gîte',
        'auberge'
    ],
    'Fournitures': [
        'fourniture',
        'papier',
        'stylo',
        'bureau',
        'matériel',
        'équipement',
        'amazon',
        'fnac',
        'bureau vallée'
    ],
    'Abonnements': [
        'abonnement',
        'subscription',
        'netflix',
        'spotify',
        'internet',
        'mobile',
        'téléphone',
        'forfait'
    ],
    'Santé': [
        'pharmacie',
        'médecin',
        'dentiste',
        'docteur',
        'clinique',
        'hôpital',
        'consultation'
    ],
    'Loisirs': [
        'cinéma',
        'théâtre',
        'concert',
        'sport',
        'livre',
        'musée',
        'parc',
        'loisir'
    ],
    'Divers': [
        'divers',
        'autre',
        'course',
        'supermarché',
        'magasin'
    ]
};
/**
 * Extrait le montant d'un texte avec différents patterns
 */ function extractAmount(text) {
    const patterns = [
        /TOTAL[:\s]*(\d+[,\.]\d{2})\s*€?/i,
        /(?:€|EUR)\s*(\d+[,\.]\d{2})/gi,
        /(\d+[,\.]\d{2})\s*(?:€|EUR)/gi,
        /(\d+[,\.]\d{2})\s*$/gm,
        /(\d{1,4}[,\.]\d{2})/g
    ];
    const amounts = [];
    for (const pattern of patterns){
        const matches = text.match(pattern);
        if (matches) {
            for (const match of matches){
                const amountMatch = match.match(/(\d+[,\.]\d{2})/);
                if (amountMatch) {
                    const amountStr = amountMatch[1].replace(',', '.');
                    const amount = parseFloat(amountStr);
                    if (amount > 0.01 && amount < 10000) {
                        amounts.push(amount);
                    }
                }
            }
        }
    }
    // Retourner le montant le plus élevé (souvent le total)
    return amounts.length > 0 ? Math.max(...amounts) : 0;
}
/**
 * Extrait la date d'un texte
 */ function extractDate(text) {
    const datePatterns = [
        /(\d{1,2}[/\-\.]\d{1,2}[/\-\.]\d{4})/g,
        /(\d{1,2}[/\-\.]\d{1,2}[/\-\.]\d{2})/g,
        /(\d{4}[/\-\.]\d{1,2}[/\-\.]\d{1,2})/g
    ];
    for (const pattern of datePatterns){
        const matches = text.match(pattern);
        if (matches) {
            for (const match of matches){
                try {
                    // Normaliser le format de date
                    const dateParts = match.split(/[/\-\.]/);
                    if (dateParts.length === 3) {
                        let [part1, part2, part3] = dateParts;
                        // Gérer l'année à 2 chiffres
                        if (part3.length === 2) {
                            part3 = '20' + part3;
                        }
                        let year, month, day;
                        if (part1.length === 4) {
                            // Format YYYY/MM/DD
                            [year, month, day] = [
                                part1,
                                part2,
                                part3
                            ];
                        } else {
                            // Format DD/MM/YYYY
                            [day, month, year] = [
                                part1,
                                part2,
                                part3
                            ];
                        }
                        // Valider et formater
                        const parsedDate = new Date(parseInt(year), parseInt(month) - 1, parseInt(day));
                        if (!isNaN(parsedDate.getTime())) {
                            return parsedDate.toISOString().split('T')[0];
                        }
                    }
                } catch (error) {
                    continue;
                }
            }
        }
    }
    // Si aucune date trouvée, retourner la date actuelle
    return new Date().toISOString().split('T')[0];
}
/**
 * Extrait le nom du marchand/fournisseur
 */ function extractMerchant(text) {
    const lines = text.split('\n').map((line)=>line.trim()).filter((line)=>line.length > 0);
    // Chercher dans les premières lignes (souvent le nom du commerce)
    for(let i = 0; i < Math.min(5, lines.length); i++){
        const line = lines[i];
        // Ignorer les lignes avec des prices, dates, ou mots-clés communs
        const skipPatterns = [
            /\d+[,\.]\d{2}/,
            /\d{2}[/\-\.]\d{2}/,
            /(ticket|facture|reçu|total|tva|cb|carte)/i
        ];
        let shouldSkip = false;
        for (const pattern of skipPatterns){
            if (pattern.test(line)) {
                shouldSkip = true;
                break;
            }
        }
        if (!shouldSkip && line.length > 3 && line.length < 50) {
            // Nettoyer et retourner le nom probable du marchand
            const merchant = line.replace(/[^\w\s\-\']/g, ' ').replace(/\s+/g, ' ').trim();
            if (merchant) {
                return merchant.split(' ').map((word)=>word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()).join(' ');
            }
        }
    }
    return "Marchand inconnu";
}
/**
 * Extrait une description de la dépense
 */ function extractDescription(text) {
    const lines = text.split('\n').map((line)=>line.trim()).filter((line)=>line.length > 0);
    const descriptions = [];
    for (const line of lines){
        // Chercher des lignes qui pourraient être des descriptions de produits/services
        if (line.length > 5 && line.length < 100 && !/^\d+[,\.]?\d*\s*€?$/.test(line) && // Pas juste un prix
        !/^\d{2}[/\-\.]\d{2}/.test(line) && // Pas juste une date
        !/^(total|tva|carte|cb)/i.test(line)) {
            descriptions.push(line);
        }
    }
    if (descriptions.length > 0) {
        // Joindre les descriptions ou prendre la plus longue
        return descriptions.slice(0, 3).join(' | ') // Max 3 descriptions
        ;
    }
    return "Description automatique";
}
/**
 * Catégorise une dépense basée sur le marchand et la description
 */ function categorizeExpense(merchant, description) {
    const textToAnalyze = `${merchant} ${description}`.toLowerCase();
    // Score par catégorie
    const categoryScores = {};
    for (const [category, keywords] of Object.entries(CATEGORY_KEYWORDS)){
        categoryScores[category] = 0;
        for (const keyword of keywords){
            if (textToAnalyze.includes(keyword.toLowerCase())) {
                categoryScores[category] += 1;
            }
        }
    }
    // Retourner la catégorie avec le meilleur score
    const bestCategory = Object.entries(categoryScores).sort(([, a], [, b])=>b - a)[0];
    return bestCategory[1] > 0 ? bestCategory[0] : 'Divers';
}
/**
 * Calcule un score de confiance pour l'extraction
 */ function calculateConfidence(data) {
    let score = 0;
    // Points pour chaque champ extrait avec succès
    if (data.amount && data.amount > 0) score += 0.3;
    if (data.merchant && data.merchant !== "Marchand inconnu") score += 0.3;
    if (data.description && data.description !== "Description automatique") score += 0.2;
    if (data.date && data.date !== new Date().toISOString().split('T')[0]) score += 0.1;
    if (data.category && data.category !== 'Divers') score += 0.1;
    return Math.min(score, 1.0);
}
/**
 * Fonction OCR simplifiée (placeholder pour test)
 * TODO: Remplacer par vraie OCR plus tard
 */ async function performOCR(imageBase64) {
    // Simuler un délai OCR
    await new Promise((resolve)=>setTimeout(resolve, 2000));
    // Pour l'instant, retourner du texte simulé basé sur timestamp pour garantir l'unicité
    const timestamp = Date.now();
    const randomAmount = (Math.random() * 50 + 10).toFixed(2);
    const merchants = [
        'Restaurant Le Bistrot',
        'Taxi Express',
        'Hotel Central',
        'Pharmacie Martin',
        'Supermarché U'
    ];
    const randomMerchant = merchants[Math.floor(Math.random() * merchants.length)];
    console.log(`🎲 Génération données simulées [${timestamp}]: ${randomMerchant} - ${randomAmount}€`);
    return `
    ${randomMerchant}
    
    Ticket de caisse
    Date: ${new Date().toLocaleDateString('fr-FR')}
    
    TOTAL: ${randomAmount}€
    
    Merci de votre visite
    CB SANS CONTACT
  `;
}
async function processExpenseContent(imageBase64, textContent) {
    let rawText = '';
    if (textContent) {
        rawText = textContent;
    } else if (imageBase64) {
        // Utilisation de l'OCR simulé
        console.log('🔍 Début OCR de l\'image...');
        rawText = await performOCR(imageBase64);
        console.log('📝 Texte OCR extrait:', rawText);
    } else {
        throw new Error("Aucun contenu fourni (image ou texte)");
    }
    if (!rawText.trim()) {
        throw new Error("Aucun texte extrait du contenu");
    }
    // Extraire les informations
    const amount = extractAmount(rawText);
    const date = extractDate(rawText);
    const merchant = extractMerchant(rawText);
    const description = extractDescription(rawText);
    const category = categorizeExpense(merchant, description);
    // Préparer les données
    const extractedData = {
        amount,
        date,
        merchant,
        description,
        category,
        rawText
    };
    // Calculer le score de confiance
    const confidence = calculateConfidence(extractedData);
    return {
        ...extractedData,
        confidence
    };
}
async function testAIProcessor() {
    const testText = `
    RESTAURANT LE PETIT BISTROT
    
    Table 5 - Serveur: Marie
    
    1x Menu du jour         15.50€
    1x Café                  2.50€
    1x Dessert               5.00€
    
    TOTAL                   23.00€
    
    CB SANS CONTACT
    15/03/2024 - 12:45
    
    Merci de votre visite
  `;
    return await processExpenseContent(undefined, testText);
}
}),
"[project]/src/app/api/whatsapp/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * API WhatsApp Webhook pour recevoir les messages avec photos de tickets
 * Intégration avec l'IA pour traitement automatique des dépenses
 */ __turbopack_context__.s([
    "GET",
    ()=>GET,
    "POST",
    ()=>POST,
    "simulateWhatsAppMessage",
    ()=>simulateWhatsAppMessage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2d$processor$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/ai-processor.ts [app-route] (ecmascript)");
;
;
// Stockage temporaire des dépenses (en production, utiliser une vraie DB)
const expenses = [];
async function POST(req) {
    try {
        console.log('📱 Webhook WhatsApp reçu');
        const body = await req.json();
        console.log('📋 Données reçues:', body);
        // Simuler la réception d'un message WhatsApp avec image
        const message = {
            from: body.from || 'demo_user',
            text: body.text || body.message || '',
            media: body.media || (body.image_url ? {
                type: 'image',
                url: body.image_url,
                caption: body.caption
            } : undefined),
            timestamp: new Date().toISOString()
        };
        console.log('📨 Message traité:', message);
        // Détecter si c'est un message de dépense
        const isExpenseMessage = detectExpenseMessage(message);
        if (!isExpenseMessage) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: true,
                message: 'Message ignoré (pas de dépense détectée)'
            });
        }
        console.log('💰 Message de dépense détecté, traitement...');
        // Traiter avec l'IA
        let extractedData;
        if (message.media?.type === 'image') {
            // Traitement image
            console.log('🖼️ Traitement image WhatsApp...');
            extractedData = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2d$processor$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["processExpenseContent"])(message.media.url);
        } else if (message.text) {
            // Traitement texte
            console.log('📝 Traitement texte WhatsApp...');
            extractedData = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$ai$2d$processor$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["processExpenseContent"])(undefined, message.text);
        } else {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: 'Aucun contenu à traiter'
            }, {
                status: 400
            });
        }
        // Enrichir avec les métadonnées WhatsApp
        const expenseRecord = {
            id: Date.now().toString(),
            ...extractedData,
            source: 'whatsapp',
            whatsapp_from: message.from,
            original_message: message.text,
            received_at: message.timestamp,
            processed_at: new Date().toISOString()
        };
        // Sauvegarder (temporairement en mémoire)
        expenses.push(expenseRecord);
        console.log('✅ Dépense sauvegardée:', expenseRecord);
        // Réponse de succès
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: true,
            message: 'Dépense traitée et sauvegardée',
            expense_id: expenseRecord.id,
            extracted_data: extractedData
        });
    } catch (error) {
        console.error('❌ Erreur webhook WhatsApp:', error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: 'Erreur traitement webhook',
            details: error instanceof Error ? error.message : 'Erreur inconnue'
        }, {
            status: 500
        });
    }
}
async function GET(req) {
    try {
        const url = new URL(req.url);
        const limit = parseInt(url.searchParams.get('limit') || '10');
        // Retourner les dernières dépenses
        const recentExpenses = expenses.sort((a, b)=>new Date(b.received_at).getTime() - new Date(a.received_at).getTime()).slice(0, limit);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: true,
            expenses: recentExpenses,
            total: expenses.length
        });
    } catch (error) {
        console.error('❌ Erreur récupération dépenses:', error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: 'Erreur récupération données'
        }, {
            status: 500
        });
    }
}
/**
 * Détecte si un message WhatsApp concerne une dépense
 */ function detectExpenseMessage(message) {
    // Mots-clés de détection
    const expenseKeywords = [
        'dépense',
        'ticket',
        'facture',
        'reçu',
        'addition',
        'restaurant',
        'taxi',
        'hotel',
        'carburant',
        'course',
        '€',
        'euro',
        'eur',
        'total',
        'prix',
        'montant'
    ];
    const textToCheck = (message.text || message.media?.caption || '').toLowerCase();
    // Présence d'image = probable dépense
    if (message.media?.type === 'image') {
        return true;
    }
    // Vérifier les mots-clés dans le texte
    for (const keyword of expenseKeywords){
        if (textToCheck.includes(keyword)) {
            return true;
        }
    }
    // Pattern de prix dans le texte
    const pricePatterns = [
        /\d+[,\.]\d{2}\s*€/,
        /€\s*\d+[,\.]\d{2}/,
        /\d+[,\.]\d{2}\s*eur/i,
        /total[:\s]*\d+/i
    ];
    for (const pattern of pricePatterns){
        if (pattern.test(textToCheck)) {
            return true;
        }
    }
    return false;
}
async function simulateWhatsAppMessage(imageUrl, text) {
    const testMessage = {
        from: 'test_user',
        text: text || 'Test dépense restaurant 25€',
        media: imageUrl ? {
            type: 'image',
            url: imageUrl,
            caption: 'Ticket restaurant'
        } : undefined,
        timestamp: new Date().toISOString()
    };
    console.log('🧪 Simulation message WhatsApp:', testMessage);
    return testMessage;
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__2bd87657._.js.map