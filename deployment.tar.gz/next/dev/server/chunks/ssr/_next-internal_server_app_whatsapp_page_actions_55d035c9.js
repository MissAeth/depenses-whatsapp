module.exports = [
"[project]/.next-internal/server/app/whatsapp/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_whatsapp_page_actions_55d035c9.js.map