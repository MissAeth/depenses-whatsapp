(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_01402f2c._.js",
  "static/chunks/src_f28787ea._.js"
],
    source: "dynamic"
});
