(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_@clerk_nextjs_dist_esm_app-router_517a7a1a._.js"
],
    source: "dynamic"
});
