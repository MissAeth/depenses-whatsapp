var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/health/route.js")
R.c("server/chunks/[root-of-the-server]__d69300b3._.js")
R.c("server/chunks/[root-of-the-server]__d7355d04._.js")
R.c("server/chunks/node_modules_next_dist_23bfe24c._.js")
R.c("server/chunks/_next-internal_server_app_api_health_route_actions_da3433c4.js")
R.m(43007)
module.exports=R.m(43007).exports
