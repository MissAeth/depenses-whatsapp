var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/update-branch/route.js")
R.c("server/chunks/[root-of-the-server]__2bff7909._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_3f50380f.js")
R.c("server/chunks/[root-of-the-server]__d7355d04._.js")
R.c("server/chunks/node_modules_ef71b6d5._.js")
R.c("server/chunks/node_modules_next_dist_bf5fd8f3._.js")
R.c("server/chunks/_next-internal_server_app_api_update-branch_route_actions_4850ca09.js")
R.m(42152)
module.exports=R.m(42152).exports
