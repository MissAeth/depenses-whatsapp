var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/send-expense/route.js")
R.c("server/chunks/[root-of-the-server]__a8d7418a._.js")
R.c("server/chunks/node_modules_next_dist_23bfe24c._.js")
R.c("server/chunks/[root-of-the-server]__76f5a536._.js")
R.c("server/chunks/node_modules_ef71b6d5._.js")
R.c("server/chunks/[root-of-the-server]__d7355d04._.js")
R.c("server/chunks/_next-internal_server_app_api_send-expense_route_actions_42d0013e.js")
R.m(85608)
module.exports=R.m(85608).exports
