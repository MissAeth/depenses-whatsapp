var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/whatsapp/route.js")
R.c("server/chunks/[root-of-the-server]__a6d89067._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_c470d57a.js")
R.c("server/chunks/node_modules_next_dist_23bfe24c._.js")
R.c("server/chunks/[root-of-the-server]__d7355d04._.js")
R.c("server/chunks/_next-internal_server_app_api_whatsapp_route_actions_d84fa5aa.js")
R.m(77949)
module.exports=R.m(77949).exports
