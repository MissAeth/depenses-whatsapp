globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/bc138e1a4ad78797.js",
    "static/chunks/2eeacf9555eceb4c.js",
    "static/chunks/f29d630d47125648.js",
    "static/chunks/a83010a40c88e84c.js",
    "static/chunks/24e31974737bf2f6.js",
    "static/chunks/turbopack-63b29e5586bf342d.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];