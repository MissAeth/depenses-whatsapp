module.exports=[51033,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app__global-error_page_actions_75761787.js.map