module.exports=[67267,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_offline_page_actions_6f2efa6f.js.map