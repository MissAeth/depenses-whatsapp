module.exports=[30112,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_whatsapp_page_actions_55d035c9.js.map