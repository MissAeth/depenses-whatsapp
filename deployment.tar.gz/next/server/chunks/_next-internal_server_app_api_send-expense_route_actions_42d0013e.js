module.exports=[84079,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_send-expense_route_actions_42d0013e.js.map