module.exports=[99610,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_whatsapp_route_actions_d84fa5aa.js.map