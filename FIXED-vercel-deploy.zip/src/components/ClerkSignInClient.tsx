"use client"
import { SignIn } from '@clerk/nextjs'
import React from 'react'

export default function ClerkSignInClient(): React.ReactElement {
  return <SignIn />
}
