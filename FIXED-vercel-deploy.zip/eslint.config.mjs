import coreWebVitalsConfig from 'eslint-config-next/core-web-vitals'

const config = [
  ...coreWebVitalsConfig,
]

export default config
